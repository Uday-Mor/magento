<?php

class Uday_Collection_Model_Collection_Address extends Mage_Core_Model_Abstract
{
    function __construct()
    {
        $this->_init('collection/collection_address');
    }
}
