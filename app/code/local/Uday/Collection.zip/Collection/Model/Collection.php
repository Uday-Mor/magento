<?php

class Uday_Collection_Model_Collection extends Mage_Core_Model_Abstract
{
    function __construct()
    {
        $this->_init('collection/collection');
    }
}
