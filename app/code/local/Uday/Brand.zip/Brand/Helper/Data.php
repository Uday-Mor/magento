<?php

class Uday_Brand_Helper_Data extends Mage_Core_Helper_Abstract
{

	public function __construct()
	{
	}
}
