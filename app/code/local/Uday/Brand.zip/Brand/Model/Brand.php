<?php

class Uday_Brand_Model_Brand extends Mage_Core_Model_Abstract
{
    function __construct()
    {
        $this->_init('brand/brand');
    }
}
